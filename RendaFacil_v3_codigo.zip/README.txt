RENDAFÁCIL v3 — arquivos separados

index.html = estrutura das telas
style.css  = visual/estilos
script.js  = cadastro, login, pontos, tarefas, ranking e indicação

Para testar:
1. Coloque os 3 arquivos na mesma pasta.
2. Abra index.html no navegador.

É um protótipo: os dados ficam no navegador e não há dinheiro real/Pix.
Não use senhas reais, RG, CPF ou dados bancários.
