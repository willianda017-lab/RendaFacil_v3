const defaultUsers=[
 {name:"Lucas",points:420},{name:"Ana",points:360},{name:"João",points:300},{name:"Maria",points:250}
];
let user=JSON.parse(localStorage.getItem("rf_user")||"null");
let tasks=[["Responder pesquisa","Pesquisa demonstrativa",20],["Assistir conteúdo","Conteúdo de teste",15],["Completar desafio","Desafio gratuito",30]];
function authMode(mode){document.getElementById("loginForm").classList.toggle("hidden",mode!=="login");document.getElementById("signupForm").classList.toggle("hidden",mode!=="signup")}
function signup(){
 let name=document.getElementById("newName").value.trim(), pass=document.getElementById("newPass").value;
 if(name.length<3||pass.length<3)return alert("Use um nome e senha com pelo menos 3 caracteres.");
 user={name,points:0,referrals:0,code:("RF"+name.replace(/\W/g,"").slice(0,4).toUpperCase()+Math.floor(100+Math.random()*900)),pass};
 localStorage.setItem("rf_user",JSON.stringify(user)); start();
}
function login(){
 let name=document.getElementById("loginName").value.trim(),pass=document.getElementById("loginPass").value;
 let saved=JSON.parse(localStorage.getItem("rf_user")||"null");
 if(saved&&saved.name===name&&saved.pass===pass){user=saved;start()}else alert("Conta não encontrada neste navegador. Crie uma conta primeiro.");
}
function start(){
 document.getElementById("auth").classList.remove("active");document.getElementById("nav").classList.remove("hidden");
 ["home","tasks","ranking","invite","profile"].forEach(x=>document.getElementById(x).classList.remove("active"));
 document.getElementById("home").classList.add("active");render();
}
function render(){
 document.getElementById("hello").textContent=user.name;document.getElementById("profileName").textContent=user.name;
 document.getElementById("points").textContent=user.points+" pontos";document.getElementById("refCode").textContent=user.code||"RFTEST";document.getElementById("refCount").textContent=user.referrals||0;
 let html=tasks.map((t,i)=>`<div class="task"><div>📋 <b>${t[0]}</b><div class="small">${t[1]}</div></div><div><div class="reward">+${t[2]} pts</div><button class="btn" onclick="complete(${i})">Fazer</button></div></div>`).join("");
 document.getElementById("tasksHome").innerHTML=html;document.getElementById("tasksAll").innerHTML=html;
 let all=[...defaultUsers,{name:user.name,points:user.points}].sort((a,b)=>b.points-a.points);
 document.getElementById("rankingList").innerHTML=all.map((u,i)=>`<div class="rank"><span>#${i+1} ${u.name}${u.name===user.name?" ⭐":""}</span><b class="reward">${u.points} pts</b></div>`).join("");
 localStorage.setItem("rf_user",JSON.stringify(user));
}
function complete(i){user.points+=tasks[i][2];render();alert("Tarefa simulada concluída! Você ganhou "+tasks[i][2]+" pontos.")}
function copyCode(){navigator.clipboard?.writeText(user.code);alert("Código copiado: "+user.code)}
function logout(){localStorage.removeItem("rf_user");location.reload()}
function show(id,el){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById(id).classList.add("active");document.querySelectorAll("nav button").forEach(b=>b.classList.remove("active"));el?.classList.add("active")}
if(user)start();
